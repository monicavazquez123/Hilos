package main;

import java.util.Random;

public class main {
	
	private static Thread t1;
	private static Thread t2;
	private static Thread t3;
	
	public static void main(String[] agrs) {
		System.out.println("Hola mundo " + agrs[0]);
		int[] vec = fillVec(agrs[0]);
		if(vec == null) {
			return;
		}
		printValues(vec);
		initThreads(vec);
		t1.start();
		t2.start();
		t3.start();
	}
	
	private static void printValues(int[] vec) {
		for(int item : vec) {
			System.out.print(item + ", ");
		}
		System.out.println("--------------------------------------------");
	}
	
	private static int[] fillVec(String agr) {
		int size = 0;
		try {
			size = Integer.valueOf(agr);			
		}catch(NumberFormatException e) {
			System.out.println("El primer argumento debe ser un numero (" + agr + ")");
			return null;
		}
		int[] vec = new int[size];
		for(int i = 0; i < size; i++) {
			Random r = new Random();
			vec[i] = r.nextInt(1000);
		}
		return vec;
	}
	
	private static void initThreads(int[] vec) {
		t1 = new Thread(() -> {
			long total = 0;
			for(int item : vec) {
				total += item;
			}
			System.out.println("Sumatoria: " + total);
		});
		
		t2 = new Thread(() -> {
			long total = 0;
			for(int item : vec) {
				total += item*item;
			}
			System.out.println("Sumatoria de Cuadrados: " + total);
		});
		
		t3 = new Thread(() -> {
			long total = 0;
			for(int item : vec) {
				total += item;
			}
			double prom = total/vec.length;
			System.out.println("Media: " + prom);
		});
	}
	
	

}
